# Sample Playbook Documentation
The collection [power_aix](../README.md) provides a sample directory of [Ansible playbook](https://docs.ansible.com/ansible/latest/user_guide/playbooks_intro.html#playbooks-intro) content, which contains various playbooks that demonstrate the use of the collection's modules.

For guides and reference, see the [Docs Site](https://ibm.github.io/ansible-power-aix/playbooks.html).


## Copyright
© Copyright IBM Corporation 2020

# Ansible Role: power_aix_vioshc
The [IBM Power Systems AIX](../../README.md) collection provides an [Ansible role](https://docs.ansible.com/ansible/latest/user_guide/playbooks_reuse_roles.html), referred to as `power_aix_vioshc`, which installs a Virtual I/O Server health assessment tool on a NIM master.

For guides and reference, see the [Docs Site](https://ibm.github.io/ansible-power-aix/roles.html).

## Copyright
© Copyright IBM Corporation 2020

<!-- This should be the location of the title of the repository, normally the short name -->
# IBM Power Systems AIX Collection

The **IBM Power Systems AIX collection** provides modules that can be used to manage configurations and
deployments of Power AIX systems. The collection content helps to include workloads on
Power platforms as part of an enterprise automation strategy through the Ansible ecosystem.

## Join the Power Research Program

Become an IBM Power Design Partner. Engage with our Power Research team across various research studies to shape the future of Anisble on Power [here](https://ibm.biz/BdyRyk).

# Ansible Content for IBM Power Systems - AIX

IBM Power Systems is a family of enterprise servers that helps transform your organization by delivering industry leading resilience, scalability and accelerated performance for the most sensitive, mission critical workloads and next-generation AI and edge solutions. The Power platform also leverages open source technologies that enable you to run these workloads in a hybrid cloud environment with consistent tools, processes and skills.

IBM Power Systems AIX collection, as part of the broader offering of **Ansible Content for IBM Power Systems**, is available from Ansible Galaxy and has community support.

## Resources

For **guides** and **reference**, please visit the [Documentation](https://ibm.github.io/ansible-power-aix/) site.

## Support

As Red Hat Ansible Certified Content, this collection is entitled to support through the Ansible Automation Platform (AAP) using the **Create issue** button on the top right corner. If a support case cannot be opened with Red Hat and the collection has been obtained either from Galaxy or GitHub, there may community help available on the [Ansible Forum](https://forum.ansible.com/). User can also raise queries or open issues at collection git hub repo [here](https://github.com/IBM/ansible-power-aix/issues)

## Release Notes and Roadmap

Please find [details](https://github.com/IBM/ansible-power-aix/blob/dev-collection/CHANGELOG.rst).

## License

[GNU General Public License, Version 3.0](https://opensource.org/licenses/GPL-3.0).

## Copyright

© Copyright IBM Corporation 2020


[def]: tails [he